let form = document.getElementById("form");
let nomeInput = document.getElementById("nomeInput");
let projetoInput = document.getElementById("projetoInput");
let msg = document.getElementById("msg");
let empresas = document.getElementById("empresas");
let add = document.getElementById("add");

form.addEventListener("submit", (e) => {
    e.preventDefault();
    formValidation();
  });
  
  let formValidation = () => {
    if (nomeInput.value === "") {
      console.log("failure");
      msg.innerHTML = "Música não pode ser vazio.";
    } else {
      console.log("success");
      msg.innerHTML = "";
      acceptData();
      add.setAttribute("data-bs-dismiss", "modal");
      add.click();
  
      (() => {
        add.setAttribute("data-bs-dismiss", "");
      })();
    }
  };
  
  let data = [{}];
  
  let acceptData = () => {
    data.push({
      nome: nomeInput.value,
      projeto: projetoInput.value,
    });
  
    localStorage.setItem("data", JSON.stringify(data));
  
    console.log(data);
    createEmpresas();
  };
  
  let createEmpresas = () => {
    empresas.innerHTML = "";
    data.map((x, y) => {
      return (empresas.innerHTML += `
      <div id=${y}>
            <span class="fw-bold">${x.nome}</span>
            <span class="fw-bold">${x.projeto}</span>
   
            <span class="options">
              <i onClick= "editEmpresa(this)" data-bs-toggle="modal" data-bs-target="#form" class="fas fa-edit"></i>
              <i onClick ="deleteEmpresa(this);createEmpresas()" class="fas fa-trash-alt"></i>
            </span>
          </div>
      `);
    });
  
    resetForm();
  };
  
  let deleteEmpresa = (e) => {
    e.parentElement.parentElement.remove();
    data.splice(e.parentElement.parentElement.id, 1);
    localStorage.setItem("data", JSON.stringify(data));
    console.log(data);
    
  };
  
  let editEmpresa = (e) => {
    let selectedEmpresa = e.parentElement.parentElement;
  
    nomeInput.value = selectedEmpresa.children[0].innerHTML;
    projetoInput.value = selectedEmpresa.children[1].innerHTML;
  
    deleteEmpresa(e);
  };
  
  let resetForm = () => {
    nomeInput.value = "";
    projetoInput.value = "";
  };
  
  (() => {
    data = JSON.parse(localStorage.getItem("data")) || []
    console.log(data);
    createEmpresas();
  })();