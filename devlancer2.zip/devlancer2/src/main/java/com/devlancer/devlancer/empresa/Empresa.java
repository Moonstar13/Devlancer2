package com.devlancer.devlancer.empresa;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Empresa {
	@Id
	private Integer id;
	private String nome;
	private String projeto;
	
	public Empresa(Integer id, String nome, String projeto) {
		super();
		this.id = id;
		this.nome = nome;
		this.projeto = projeto;
		
	}
	
	public Empresa() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getProjeto() {
		return projeto;
	}
	public void setProjeto(String projeto) {
		this.projeto = projeto;
	}

	@Override
	public String toString() {
		return "Empresa [id=" + id + ", nome=" + nome + ", projeto=" + projeto + "]";
	}

	public static void add(Empresa empresa) {
		// TODO Auto-generated method stub
		
	}

}
