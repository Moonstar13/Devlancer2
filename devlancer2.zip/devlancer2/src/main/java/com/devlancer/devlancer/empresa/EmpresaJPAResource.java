package com.devlancer.devlancer.empresa;


import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder; 
@RestController
public class EmpresaJPAResource {
	@Autowired
	private EmpresaRepository empresaRepository;
	
	@GetMapping("/jpa/empresa")
	public List<Empresa> retrieveAllEmpresa(){
		List<Empresa> empresa = empresaRepository.findAll();
		
		return empresa;
 	}
	
	@DeleteMapping("/jpa/empresa/{id}")
	public void deleteUser(@PathVariable int id ) {
		empresaRepository.deleteById(id);
		
		
	}
	@PostMapping("/jpa/empresa")
	public ResponseEntity<Object> createUser(@RequestBody Empresa empresa){
		Empresa savedEmpresa = empresaRepository.save(empresa);
		URI location = ServletUriComponentsBuilder
				.fromCurrentRequest()
				.path("/{id}")
				.buildAndExpand(savedEmpresa.getId()).toUri();
		  return ResponseEntity.created(location).build();
		
	}

}
