package com.devlancer.devlancer.empresa;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class EmpresaDaoService {
	private static final List<Empresa> Empresa = null;

	private static List <Empresa> empresa = new ArrayList<>();
	
	private int empresaCount =3;
	
	static {
		Empresa.add(new Empresa(1, "Ponto Frio", null));
		Empresa.add(new Empresa(2, "Apple", null));
		Empresa.add(new Empresa(3, "Samsung",null ));
	}
	
	public List<Empresa> findAll () {
		return Empresa;
	}
	
	public Empresa save(Empresa empresa) {
		if (empresa.getId() == 0) {
			empresa.setId(++empresaCount);
		}
		Empresa.add((com.devlancer.devlancer.empresa.Empresa) Empresa);
		return (com.devlancer.devlancer.empresa.Empresa) Empresa;
	}
	
	public Empresa findOne(Integer id) {
		for (Empresa empresa:Empresa) {
			if (empresa.getId() == id) {
				return empresa;
			}
		}
		return null;
	}
}

