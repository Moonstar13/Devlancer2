package com.devlancer.devlancer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevlancerApplicationTests {

	@Test
	void contextLoads() {
	}

}
