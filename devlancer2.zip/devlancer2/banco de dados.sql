create database musicas_db;
use musicas_db;
select * from musicas;
